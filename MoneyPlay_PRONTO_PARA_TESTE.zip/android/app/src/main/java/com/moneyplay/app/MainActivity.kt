package com.moneyplay.app

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import com.android.billingclient.api.*

class MainActivity : Activity() {
    // TROQUE por seu endereço HTTPS de produção antes de publicar.
    private val serverUrl = "https://SEU-DOMINIO-DE-PRODUCAO.example/"

    private lateinit var web: WebView
    private lateinit var billing: BillingClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(-1, -1)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            webViewClient = WebViewClient()
            loadUrl(serverUrl)
        }
        setContentView(web)

        billing = BillingClient.newBuilder(this)
            .setListener { result, purchases ->
                if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
                    // A compra deve ser enviada ao backend para verificação server-side.
                    // O backend, e somente ele, deve liberar o VIP.
                    for (purchase in purchases) {
                        // TODO: POST token + productId para /api/google-play/verify
                    }
                }
            }
            .enablePendingPurchases(
                PendingPurchasesParams.newBuilder()
                    .enableOneTimeProducts()
                    .build()
            )
            .build()

        billing.startConnection(object : BillingClientStateListener {
            override fun onBillingServiceDisconnected() {}
            override fun onBillingSetupFinished(result: BillingResult) {}
        })
    }

    fun startVipPurchase(productId: String) {
        // A UI web deve chamar uma ponte nativa em uma versão posterior.
        // productId esperado: moneyplay_vip_ouro ou moneyplay_vip_diamante
    }

    override fun onDestroy() {
        billing.endConnection()
        web.destroy()
        super.onDestroy()
    }
}
