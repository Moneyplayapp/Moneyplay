# Money Play — pacote para preparação da Google Play

Incluído:
- backend Flask do pacote enviado;
- VIP não é mais ativado automaticamente por um POST;
- projeto Android Studio com target SDK 36;
- integração inicial do Google Play Billing;
- documentação de configuração dos produtos VIP.

IMPORTANTE:
Este ZIP é uma base de produção preparada, mas não pode ser considerado uma publicação 100% concluída sem:
- URL HTTPS real do backend;
- configuração dos produtos/assinaturas na sua conta Play Console;
- verificação server-side das compras;
- chave de assinatura do aplicativo;
- política de privacidade/termos publicados;
- testes e revisão de conformidade da Google Play.

Não inclua senhas ou chaves privadas no aplicativo.
